package com.aperio.services;

import java.util.ArrayList;

import com.aperio.beans.Video;
import com.aperio.dao.DataAccessObjectLayer;

/**
 * @author Aingaran Elango
 *
 */

public class ServiceLayer {

	DataAccessObjectLayer dataAccessObject = new DataAccessObjectLayer();

	public DataAccessObjectLayer getDataAccessObject() {
		return dataAccessObject;
	}

	public void setDataAccessObject(DataAccessObjectLayer dataAccessObject) {
		this.dataAccessObject = dataAccessObject;
	}


	/**

	public int name(int a) throws SQLException	{
		return dataAccessObject.name(a);
	}

	 */

	/**************** All Service methods go here ****************/


	public boolean addVideo(Video video) {
		return dataAccessObject.addVideo(video);
	}
	public boolean deleteVideo(Video video) {
		return dataAccessObject.deleteVideo(video);
	}
	public ArrayList<Video> listVideos(Video video) {
		return dataAccessObject.listVideos(video);
	}
	public ArrayList<Video> listAllVideos() {
		return dataAccessObject.listAllVideos();
	}

	public boolean updateVideo(Video video) {
		// TODO Auto-generated method stub
		return dataAccessObject.updateVideo(video);
	}
}
