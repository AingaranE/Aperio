package com.aperio.helpers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author Aingaran Elango
 *
 */

public class DbTransaction {

	static final String URL = "jdbc:oracle:thin:@ingnrgpilphp01:1521:ORCLILP";

	static final String USER = "aja18b";
	static final String PASS = "aja18b";

	private Connection connection;

	public Connection getConnection() {
		try {
			closeConnection();
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(URL,USER,PASS);
		} catch (SQLException e) {
			System.out.println("Error during DbTransaction get Connection.");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			System.out.println("Error during DbTransaction get Connection. (Check 'ojdbc.jar')");
			e.printStackTrace();
		}
		return connection;
	}

	public void closeConnection() {
		try	{
			if(connection != null && connection.isClosed() == false) {
				connection.close();
			}
			connection = null;
		}
		catch(SQLException e) {
			System.out.println("Error during DbTransaction Connection close.");
			e.printStackTrace();
		}
	}
}
