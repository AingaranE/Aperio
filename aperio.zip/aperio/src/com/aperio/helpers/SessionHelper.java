package com.aperio.helpers;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class SessionHelper {
	
	public Session getHibernateSession() {
		
		try {
			SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
			Session session = sessionFactory.openSession();
			System.out.println("the session object is :: "+session);
			return session;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public void closeHibernateSession(Session session) {
		
		if (session!=null) {
			session.close();
			System.out.println("Session closed successfully");
		}
		else {
			System.out.println("Session already closed");
		}
	}
}
