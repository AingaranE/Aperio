package com.aperio.dao;

import java.util.ArrayList;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.jdbc.core.JdbcTemplate;

import com.aperio.beans.Video;
import com.aperio.helpers.SessionHelper;

/**
 * @author Aingaran Elango
 *
 */
public class DataAccessObjectLayer {

	private JdbcTemplate jdbctmpl;

	public JdbcTemplate getJdbctmpl() {
		return jdbctmpl;
	}

	public void setJdbctmpl(JdbcTemplate jdbctmpl) {
		this.jdbctmpl = jdbctmpl;
	}

	/**

	 public boolean addVideo(video video) throws SQLException	{
		DbTransaction dbT = new DbTransaction();
		Connection connection = dbT.getConnection();


			String query = "INSERT INTO ADMIN_VOD (ID, NAME, CATEGORY, DURATION, FREQUENCY, STARTTIME, COST, URL) VALUES (video_id.nextval, ?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement preparedStatement = null;
			int result = 0;
			try {
				preparedStatement = connection.prepareStatement(query);

				preparedStatement.setString(1, video.getName());
				preparedStatement.setString(2, video.getCategory());
				preparedStatement.setInt(3, video.getDuration());
				preparedStatement.setDouble(6, video.getCost());
				preparedStatement.setString(4, video.getFrequency());
				preparedStatement.setString(5, video.getStartTime());
				preparedStatement.setString(7, video.getUrl());

				result = preparedStatement.executeUpdate();

			} catch (SQLException e) {
				System.out.println("Error in DataAccessObject (SQLException).");
				e.printStackTrace();
				return false;

			} finally {

				if (preparedStatement != null) {
					preparedStatement.close();
				}
				if (connection != null) {
					connection.close();
				}
				if (result == 0) {
					return false;
				}
				if (result == 1) {
					return true;
				}
			}
			return false;
	}

	 */

	/**************** All DataAccessObject methods go here ****************/


	public boolean addVideo(Video video) {

		try {
			SessionHelper sessionHelper = new SessionHelper();
			Session session = sessionHelper.getHibernateSession();
			session.save(video);
			session.beginTransaction().commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}

	}
	
	public boolean deleteVideo(Video video) {

		try {
			SessionHelper sessionHelper = new SessionHelper();
			Session session = sessionHelper.getHibernateSession();
			session.delete(video);
			session.beginTransaction().commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}

	}
	
	public ArrayList<Video> listVideos(Video video) {
		SessionHelper sessionHelper = new SessionHelper();
		Session session = sessionHelper.getHibernateSession();
		Query q=session.createQuery("FROM Video WHERE URL = :n");
		q.setParameter("n", video.getUrl());
		ArrayList<Video> videos = (ArrayList<Video>) q.list();
		return videos;
	}
	
	public ArrayList<Video> listAllVideos() {
		SessionHelper sessionHelper = new SessionHelper();
		Session session = sessionHelper.getHibernateSession();
		Query q=session.createQuery("FROM Video");
		ArrayList<Video> videos = (ArrayList<Video>) q.list();
		return videos;
	}

	public boolean updateVideo(Video video) {
		try {
			SessionHelper sessionHelper = new SessionHelper();
			Session session = sessionHelper.getHibernateSession();
			session.update(video);
			session.beginTransaction().commit();
			return true;
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

}
