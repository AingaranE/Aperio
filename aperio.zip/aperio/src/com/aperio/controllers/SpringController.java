package com.aperio.controllers;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.aperio.beans.Video;
import com.aperio.services.ServiceLayer;

/**
 * @author Aingaran Elango
 *
 */
@Controller
@SessionAttributes
public class SpringController {

	@Autowired
	ServiceLayer serviceLayerObject = new ServiceLayer();

	public ServiceLayer getServiceLayerObject() {
		return serviceLayerObject;
	}

	public void setServiceLayerObject(ServiceLayer serviceLayerObject) {
		this.serviceLayerObject = serviceLayerObject;
	}



	/*@RequestMapping("/transaction")
	public ModelAndView showTransaction() {
		return new ModelAndView("transactionadd", "command", new Transaction());
	}

	@RequestMapping(value = "/addTransaction", method = RequestMethod.POST)
	public ModelAndView addTransaction(@ModelAttribute("transactionadd")Transaction transaction, 
			BindingResult result) {
		String message="";
		int r=0;
		if (!transaction.getV_rc_number().isEmpty())  {
			String c=serviceLayerObject.insertData(transaction);
			System.out.println(c);
			int length = c.length();
			if(length==1){
				r=Integer.parseInt(c);			
			}
			else{
				message="Enter a valid registration Number";
			}

			if(r>0){
				message="Customer registration is successful.";
			}
		}

		return new ModelAndView("ratecard", "message", message);
	}*/

	/**************** All controller methods go here ****************/


	@RequestMapping("/video")
	public ModelAndView addVideo() {
		/*Video video = new Video();
		video.setName("video name");
		video.setCategory("Entertainment");
		video.setCost(500);
		video.setDuration(120);
		video.setFrequency("daily");
		video.setStartTime("10:30PM");
		video.setUrl("url");*/
		return new ModelAndView("addvideo", "command",new Video());
	}
	
	@RequestMapping(value = "/addvideos", method = RequestMethod.POST)
	public ModelAndView addVideos(@ModelAttribute("addvideo")Video video, 
	BindingResult result) {
		String message="";
		if (!video.getName().isEmpty())  {
			boolean c=serviceLayerObject.addVideo(video);
			System.out.println(c);
			if(c){
				System.out.println("Getting success message");
				message="Video Added Successfully";
			}
			else{
				message="Video Adding failed.";
			}
		}
		else {
			System.out.println("object empty");
		}
		System.out.println("Aproaching end");
		return new ModelAndView("addvideo", "message", message);
	}
	
	@RequestMapping("/videoview")
	public ModelAndView sendVideo() {
		ArrayList<Video> videos = serviceLayerObject.listAllVideos();
		ModelAndView model1=new ModelAndView();
		model1.addObject("count", videos.size());
		int i =0;
		for(Video v:videos){
		model1.addObject("command"+i, v);
		i++;
		}
		System.out.println("returning model");
		return model1;
	}
	
	@RequestMapping(value = "/updatevideos", method = RequestMethod.POST)
	public ModelAndView updateVideos(@ModelAttribute("videoview")Video video, HttpServletRequest request
	 ) {
		String message="";
		System.out.println(video.getId());
		String submit = request.getParameter("submit");
	
		System.out.println(submit);
		if(submit.equalsIgnoreCase("update")){
		if (!video.getName().isEmpty())  {
			boolean c=serviceLayerObject.updateVideo(video);
			System.out.println(c);
			if(c){
				System.out.println("Getting success message");
				message="Video updated Successfully";
			}
			else{
				message="Video updation failed.";
			}
		}
		else {
			System.out.println("object empty");
		}
		System.out.println("Aproaching end");
		return new ModelAndView("videoview", "message", message);
		}
		else {
			if (!video.getName().isEmpty())  {
				boolean c=serviceLayerObject.deleteVideo(video);
				System.out.println(c);
				if(c){
					System.out.println("Getting success message");
					message="Video deleted Successfully";
				}
				else{
					message="Video deletion failed.";
				}
			}
			else {
				System.out.println("object empty");
			}
			System.out.println("Aproaching end");
			
			return new ModelAndView("videoview", "message", message);
		}
	}
	

}
