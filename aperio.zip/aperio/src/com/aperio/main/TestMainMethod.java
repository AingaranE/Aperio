package com.aperio.main;

import java.util.ArrayList;

import org.hibernate.Session;

import com.aperio.beans.Video;
import com.aperio.helpers.SessionHelper;
import com.aperio.services.ServiceLayer;

public class TestMainMethod {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionHelper sessionHelper = new SessionHelper();

		Session session = sessionHelper.getHibernateSession();
		
		Video video = new Video();
		
		video.setId(6);
		video.setName("video name");
		video.setCategory("Entertainment");
		video.setCost(500);
		video.setDuration(120);
		video.setFrequency("weekly");
		video.setStartTime("10:30PM");
		video.setUrl("lur");
		
		//ServiceLayer serviceLayerObject = new ServiceLayer();
		//serviceLayerObject.deleteVideo(video);
		/*ArrayList<Video> videos = serviceLayerObject.listAllVideos();
		for(Video v:videos)
		System.out.println(v.getId());*/
		session.update(video);
		
		session.beginTransaction().commit();
		
	}

}
